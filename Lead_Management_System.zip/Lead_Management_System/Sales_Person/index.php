<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Basic Lead Management System</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"/>
    <link rel="stylesheet" href="custom.css">
</head>
<body>
<div style="margin-top: 10px;"><img width="150px" height ="150px" src="ssdb.png" class="center-block"/></div>
<div class="container">
    <h1>Lead Management System </h1>
    <h2>1. CRUD Feature for Sales Person</h2>
    <a href="#" data-toggle="modal" data-target="#myModal" class="btn btn-primary pull-right bottom-gap">Create Sales Person <i class="fa fa-plus" aria-hidden="true"></i></a>
    <table class="table table-bordered">
        <thead id="thead" style="background-color:#135361">
            <tr>
                <th>Sr.No.</th>
                <th>Employee ID</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody id="crudData"></tbody>
    </table>
</div>
<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header" style="background-image: url('background_img.jpg');">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h3 class="modal-title"><img src="ssdb.png"/>  Create Sales Person.</h3>
            </div>
            <div class="modal-body">
                <form id="profileForm" enctype="multipart/form-data">
                   <div class="row">
                       <div class="col-md-4">
                           <div class="form-group">
                               <label for="first_name"> First Name <span class="field-required">*</span></label>
                               <input type="text" name="first_name" id="first_name" placeholder=" First Name" class="form-control">
                           </div>
                           <div class="form-group">
                               <label for="last_name"> Last Name <span class="field-required">*</span></label>
                               <input type="text" name="last_name" id="last_name" placeholder=" Last Name" class="form-control">
                           </div>
                       </div>
                       <div class="col-md-4">
                            <div class="form-group">
                               <label for="employee_id">Employee ID <span class="field-required">*</span></label>
                               <input type="text" name="employee_id" id="employee_id" placeholder="Employee ID" class="form-control">
                           </div>
                           <div class="form-group">
                               <label for="email">Email <span class="field-required">*</span></label>
                               <input type="text" name="email" id="email" placeholder="Email" class="form-control">
                           </div>
                       </div>
                       <div class="col-md-4">
                           <div class="form-group">
                               <label for="phone">Phone <span class="field-required">*</span></label>
                               <input type="text" id="phone" name="phone" placeholder="Phone" ><br><br>
                              <small>Format: 1234567890</small><br><br>
                           </div>
                       </div>
                   </div>
                    <div class="row">
                        <div class="col-md-4">
                            <input type="hidden" name="editId" id="editId" value="" />
                            <input type="submit" name="submitBtn" id="submitBtn" class="btn btn-primary"><i class="fa fa-spinner fa-spin" id="spinnerLoader" ></i> <span id="buttonLabel"></span> </input>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<h1> Leads </h1>
    <a href="http://localhost/SSDB_Assign/Lead/index.php" class="btn btn-primary align center-block">Leads<i aria-hidden="true"></i></a>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</body>
</html>
<script type="text/javascript">
  
$("#profileForm").submit(function(event){
        event.preventDefault(); //prevent default action 
        var employee_id = $("#employee_id").val();
        var first_name = $("#first_name").val();
        var last_name = $("#last_name").val();
        var email = $("#email").val();
        var phone = $("#phone").val();
        var editId = $("#editId").val();
        var formdata=new FormData(this);
        if (employee_id == ""){
         alert("Please enter Employee ID");
        $("#employee_id").focus();
    }else if (first_name == ""){
        alert("Please enter first name");
        $("#first_name").focus();
    }else if (last_name == ""){
        alert("Please enter last name");
        $("#last_name").focus();
    }else if (email == "") {
         alert("Please enter email");
        $("#email").focus();
    }else if (phone == "") {
         alert("Please enter Phone Number");
        $("#phone").focus();
    }
        formdata.append('type',"insert");
        $.ajax({
           url:"sales_person.php",
           method:"POST",
           data:formdata,
           dataType:'JSON',
           contentType: false,
           cache: false,
           processData: false,
           success:function(data)
           {
                 $("#myModal").modal('hide');

                  getAllData();
             
           }
          });
    });
$( document ).ready(function() {
    getAllData();
    console.log( "ready!" );
});
function getAllData() {
    $.post("sales_person.php",{type:"getData"},function (allData) {
              $("#crudData").html(allData);
    });
      
}
function editData(editId,employee_id,first_name,last_name,email,phone) {
  console.log(editId,employee_id,first_name,last_name,email,phone);
    $("#editId").val(editId);
    $("#employee_id").val(employee_id);
    $("#first_name").val(first_name);
    $("#last_name").val(last_name);
    $("#email").val(email);
    $("#phone").val(phone);
    $("#myModal").modal('show');
}
function deleteData(deleteId) {
    if(confirm("Are you sure to delete this ?")){
        $('#deleteSpinner'+deleteId).show('fast');
        $.post("sales_person.php",{type:"deleteData",deleteId:deleteId},function (response) {
            if (response == "deleted") {
                $('#deleteSpinner'+deleteId).hide('fast');
                getAllData();
            }
        });
    }
}
</script>