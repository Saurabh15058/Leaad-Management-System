<?php
include "config.php";
$crudObj = new CrudOperations();

if ($_REQUEST['type'] == "insert") {
    $employee_id = $_REQUEST['employee_id'];
    $first_name = $_REQUEST['first_name'];
    $last_name = $_REQUEST['last_name'];
    $email = $_REQUEST['email'];
    $phone = $_REQUEST['phone'];
    $editId = $_REQUEST['editId'];
    $save = $crudObj->saveData($connection,$employee_id,$first_name,$last_name,$email,$phone,$editId);
    if ($save){
        echo json_encode(array("type"=>"insert_success"));
    }
}

if ($_REQUEST['type'] == "getData") {
    $sr = 1;
    $tableData = '';
    $allData = $crudObj->getAllData($connection);
    if ($allData->num_rows>0) {
        while ($row = $allData->fetch_object()) {
            $tableData .= ' <tr>
                <td>'.$sr.'</td>
                <td>'.$row->employee_id.'</td>
                <td>'.$row->first_name.'</td>
                <td>'.$row->last_name.'</td>
                <td>'.$row->email.'</td>
                <td>'.$row->phone.'</td>
                <td><a href="javaScript:void(0)" onclick="editData(\''.$row->id.'\',\''.$row->employee_id.'\',\''.$row->first_name.'\',\''.$row->last_name.'\',\''.$row->email.'\',\''.$row->phone.'\');" class="btn btn-success btn-sm">Edit <i class="fa fa-pencil-square-o"></i></a>
                <a href="javaScript:void(0)" onclick="deleteData(\''.$row->id.'\');" class="btn btn-danger btn-sm">Delete <i class="fa fa-trash-o"></i></a>
                <i class="fa fa-spinner fa-spin" id="deleteSpinner'.$row->id.'" style="color: #ff195a;display: none"></i></td>
            </tr>';
            $sr++;
        }
    }
            echo $tableData;
}

if ($_REQUEST['type'] == "deleteData"){
    $deleteId = $_REQUEST['deleteId'];
    $delete = $crudObj->deleteData($connection,$deleteId);
    if ($delete){
        echo "deleted";
    }
}

// MySQL query (APIs).....

class CrudOperations
{
    public function saveData($connection,$employee_id,$first_name,$last_name,$email,$phone,$editId)
    {
        if ($editId == "") {
            $query = "INSERT INTO sales_person SET employee_id='$employee_id',first_name='$first_name',last_name='$last_name',email='$email',phone='$phone'";
        }else{
            $query = "UPDATE sales_person SET employee_id='$employee_id',first_name='$first_name',last_name='$last_name',email='$email',phone='$phone' WHERE id='$editId'";
        }
        
        $result = $connection->query($query) or die("Error in saving data".$connection->error);
        return $result;
    }

    public function getAllData($connection)
    {
        $query = "SELECT * FROM sales_person";
        $result = $connection->query($query) or die("Error in getting data".$connection->error);
        return $result;
    }

    public function deleteData($connection,$deleteId){
        $query = "DELETE FROM sales_person WHERE id='$deleteId'";
        $result = $connection->query($query) or die("Error in deleting data".$connection->error);
        return $result;
    }
}