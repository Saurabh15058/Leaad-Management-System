<?php
$databaseHost = 'localhost';
$databaseName = 'lead_management';
$databaseUsername = 'root';
$databasePassword = '';

$connection = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName); 
 
?>