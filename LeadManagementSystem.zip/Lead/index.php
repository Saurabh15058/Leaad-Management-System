<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Basic Lead Management System</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"/>
    <link rel="stylesheet" href="custom.css">
</head>
<body>
<div style="margin-top: 10px;"><img width="150px" height ="150px" src="ssdb.png" class="center-block"/></div>
<div class="container">
    <h1>Lead Management System </h1>
    <h2>2.CRUD Feature for Leads</h2>
    <a href="#" data-toggle="modal" data-target="#myModal" class="btn btn-primary pull-right bottom-gap">Create Leads <i class="fa fa-plus" aria-hidden="true"></i></a>
    <table class="table table-bordered">
        <thead id="thead" style="background-color:#135361">
            <tr>
                <th>Sr.No.</th>
                <th>Name</th>
                <th>Organization</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Source of lead</th>
                <th>Creation Date</th>
                <th>Record of interactions</th>
                <th>Date & Time</th>
                <th>Interaction details</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody id="crudData"></tbody>
    </table>
</div>
<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header" style="background-image: url('background_img.jpg');">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h3 class="modal-title"><img src="ssdb.png"/> Details of Leads</h3>
            </div>
            <div class="modal-body">
                <form id="profileForm" enctype="multipart/form-data">
                   <div class="row">
                       <div class="col-lg-4">
                          <div class="form-group">
                               <label for="name"> Name <span class="field-required">*</span></label>
                               <input type="text" name="name" id="name" placeholder="Name" class="form-control">
                           </div>
                           <div class="form-group">
                               <label for="organization"> Organization <span class="field-required">*</span>
                               </label>
                               <input type="text" name="organization" id="organization" placeholder=" Organization" class="form-control">
                           </div>
                           <div class="form-group">
                               <label for="email"> Email <span class="field-required">*</span></label>
                               <input type="text" name="email" id="email" placeholder="Email" class="form-control">
                           </div>
                       </div>
                       <div class="col-lg-4">
                           <div class="form-group">
                              <label for="phone"> Phone <span class="field-required">*</span></label>
                              <input type="text" id="phone" name="phone" placeholder="Phone" ><br><br>
                              <small>Format: 1234567890</small><br><br>
                           </div>
                           <div class="form-group">
                               <label for="source_of_lead">Source of lead<span class="field-required">*</span>
                               </label>
                               <input type="text" name="source_of_lead" id="source_of_lead" placeholder="Source of lead" class="form-control">
                           </div>
                           <div class="form-group">
                               <label for="creation_date">Creation Date<span class="field-required">*</span>
                               </label>
                               <input type="date" name="creation_date" id="creation_date" placeholder="Creation Date" class="form-control">
                           </div>
                        </div>
                           <div class="col-lg-4">
                           <div>
                               <p1 style = "font-family:georgia,garamond,serif;font-size:15px;font-style:italic;">Lead Activities:</p1><br>
                               <p2>Record of interactions</p2><br>
                               <input type="radio" id="meeting" name="type_of_interaction" value="meeting">
                                <label for="meeting">Meeting</label><br>
                                <input type="radio" id="email" name="type_of_interaction" value="email">
                                <label for="email">Email</label><br>
                                <input type="radio" id="call" name="type_of_interaction" value="call">
                                <label for="call">Call</label> 
                           </div>
                           <div>
                               <p1>Date & Time of Interaction:</p1><br>
                              <label for="date_time">Date & Time</label><br> 
                              <input type="datetime-local" style="width: 160px" id="date_time" name="date_time">
                           </div>
                           <div>
                              <label for="interaction">Interaction details:</label><br> 
                              <textarea id="interaction" name="interaction" placeholder="Interaction Details">
                              </textarea>
                           </div>
                       </div>
                   </div>
                    <div class="row">
                        <div class="col-lg-4">
                            <input type="hidden" name="editId" id="editId" value="">
                            <input type="submit" name="submitBtn" id="submitBtn" class="btn btn-primary"><i class="fa fa-spinner fa-spin" id="spinnerLoader" ></i> <span id="buttonLabel"></span> </input>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal" >Close</button>
            </div>
        </div>
    </div>
</div>

<div style="margin-top: 10px;"></div>
<div class="container">
    <h1> Lead Scoring/Prioritization </h1>
    <table class="table table-bordered">
        <thead id="thead" style="background-color:#135361">
            <tr style="color: white; font-size: 30px;">
                <th>Label</th>
                <th>Score Range</th>
            </tr>
            <tr style="color: red; font-size: 20px;">
              <td><input type="checkbox" />  Hot Lead </td>
              <td>70 or more points</td>
            </tr>
            <tr style="color: yellow; font-size: 20px;">
              <td><input type="checkbox" />  Warm Lead</td>
              <td>50 to 69 points</td>
            </tr>
            <tr style="color: #EE8934; font-size: 20px;">
              <td><input type="checkbox" />  Cold Lead</td>
              <td>0 to 49 points</td>
            </tr>
        </thead>
    </table>
</div>

<div style="margin-top: 10px;"></div>
<div class="container">
    <h1> Assign Leads </h1>
    <a href="http://localhost/sales_person/index.php" class="btn btn-primary pull-right bottom-gap">Assignee<i class="fa fa-plus" aria-hidden="true"></i></a>
    <table class="table table-bordered">
        <thead id="thead" style="background-color:#135361">
            <tr>
                <th>Sr.No.</th>
                <th>Name</th>
                <th>Organization</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Source of lead</th>
                <th>Creation Date</th>
                <th>Record of interactions</th>
                <th>Date & Time</th>
                <th>Interaction details</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody id="crudDataA"></tbody>
    </table>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</body>
</html>


<script type="text/javascript">

$("#profileForm").submit(function(event){
        event.preventDefault(); //prevent default action 
        var name = $("#name").val();
        var organization = $("#organization").val();
        var email = $("#email").val();
        var phone = $("#phone").val();
        var source_of_lead = $("#source_of_lead").val();
        var creation_date = $("#creation_date").val();
        var type_of_interaction = $("#meeting").val();
        var type_of_interaction = $("#email").val();
        var type_of_interaction = $("#call").val();
        var date_time = $("#date_time").val();
        var interaction = $("#interaction").val();
        var editId = $("#editId").val();
        var formdata=new FormData(this);
        if (name == ""){
         alert("Please enter Name");
        $("#name").focus();
    }else if (organization == ""){
        alert("Please enter Organization");
        $("#organization").focus();
    }else if (email == ""){
        alert("Please enter Email");
        $("#email").focus();
    }else if (phone == "") {
         alert("Please enter phone number");
        $("#phone").focus();
    }else if (source_of_lead == "") {
         alert("Please enter Source of lead");
        $("#source_of_lead").focus();
    }else if (creation_date == "") {
         alert("Please enter creation date");
        $("#creation_date").focus();
    }else if (date_time == "") {
         alert("Please enter date and time");
        $("#date_time").focus();
    }else if (interaction == "") {
         alert("Please enter interaction details");
        $("#interaction").focus();
    }
        formdata.append('type',"insert");
        $.ajax({
           url:"lead.php",
           method:"POST",
           data:formdata,
           dataType:'JSON',
           contentType: false,
           cache: false,
           processData: false,
           success:function(data)
           {
                 $("#myModal").modal('hide');

                  getAllData();
             
           }
          });
    });
$( document ).ready(function() {
    getAllData();
    console.log( "ready!" );
});


function getAllData() {
    $.post("lead.php",{type:"getData"},function (allData) {
              $("#crudData").html(allData);
               $("#crudDataA").html(allData);
    });
      
}
function editData(editId,name,organization,email,phone,source_of_lead,creation_date,type_of_interaction,type_of_interaction,type_of_interaction,date_time,interaction) {
  console.log(editId,name,organization,email,phone,source_of_lead,creation_date,type_of_interaction,date_time,interaction);
    $("#editId").val(editId);
    $("#name").val(name);
    $("#organization").val(organization);
    $("#email").val(email);
    $("#phone").val(phone);
    $("#source_of_lead").val(source_of_lead);
    $("#creation_date").val(creation_date);
    $("#type_of_interaction").val(type_of_interaction);
    $("#date_time").val(date_time);
    $("#interaction").val(interaction);
    $("#myModal").modal('show');
}
function deleteData(deleteId) {
    if(confirm("Are you sure to delete this ?")){
        $('#deleteSpinner'+deleteId).show('fast');
        $.post("lead.php",{type:"deleteData",deleteId:deleteId},function (response) {
            if (response == "deleted") {
                $('#deleteSpinner'+deleteId).hide('fast');
                getAllData();
            }
        });
    }
}

$('#myModal').submit(function() {

// submission stuff

$('#myModal').modal('hide');
return false;
});
</script>